<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="admin_home.php">Admin Dashboard</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="update_admin.php">Profile</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_doctors.php">Doctors</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_patients.php">Patients</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="add_about.php">About Us</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_services.php">Services</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_tests.php">Tests</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_appointments.php">Appointments</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="view_feedbacks.php"> Feedbacks</a>
      </li>
 
      
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
    </ul>
  </div>
</nav>
